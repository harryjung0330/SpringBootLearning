package com.example.springBootEx;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CoffeeRepository extends CrudRepository<Coffee, String>
{
    @Query(value = "SELECT * FROM COFFEE WHERE name = ?1", nativeQuery = true)
   List<Coffee> findByName(String name);

    @Query(value = "SHOW TABLES", nativeQuery = true)
    List<String> showAllTables();
}

