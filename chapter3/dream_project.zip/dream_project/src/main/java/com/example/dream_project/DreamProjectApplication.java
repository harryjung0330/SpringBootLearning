package com.example.dream_project;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@SpringBootApplication
public class DreamProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DreamProjectApplication.class, args);
	}

}

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
class User{
	private final String userId;
	private String userName;
	private String userPhoneNumb;
	private String userLoginId;
	private String userPs;

	public User(String userName, String userPhoneNumb, String userLoginId, String userPs)
	{
		userId = UUID.randomUUID().toString();
		this.userName = userName;
		this.userPhoneNumb = userPhoneNumb;
		this.userLoginId = userLoginId;
		this.userPs = userPs;
	}

	String getUserId()
	{
		return userId;
	}

	String getUserName()
	{
		return userName;
	}

	String getUserPhoneNumb()
	{
		return userPhoneNumb;
	}

	String getUserLoginId()
	{
		return userLoginId;
	}

	String getUserPs()
	{
		return userPs;
	}

	void setUser(User user)
	{
		userName = user.getUserName();
		userPhoneNumb = user.getUserPhoneNumb();
		userLoginId = user.getUserLoginId();
		userPs = user.getUserPs();
	}
}

@RestController
@RequestMapping("/user")
class UserController{
	private static UserController userController = new UserController();
	private static Users users = new Users();

	private UserController()
	{

	}

	UserController getUserController()
	{
		return userController;
	}

	@GetMapping("")
	Iterable<User> getAllUsers()
	{
		return users.users;
	}

	@GetMapping("/{id}")
	User getUser(@PathVariable String id)
	{
		for(User user: users.users)
		{
			if(user.getUserId().equals(id))
			{
				return user;
			}
		}

		return null;
	}

	@PostMapping("")
	User createNewUser(@RequestBody User user)
	{
		users.users.add(new User(user.getUserName(), user.getUserPhoneNumb(), user.getUserLoginId(), user.getUserPs()));
		return users.users.get(users.users.size() - 1);
	}

	@PutMapping("/{id}")
	User changeUser(@PathVariable String id ,@RequestBody User user)
	{
		for(User aUser : users.users)
		{
			if(aUser.getUserId().equals(id))
			{
				aUser.setUser(user);
				return aUser;
			}
		}

		return null;
	}

	@DeleteMapping("/{id}")
	void deleteUser(@PathVariable String id )
	{
		for(int ind = 0 ; ind < users.users.size(); ind++)
		{
			if(users.users.get(ind).getUserId().equals(id))
			{
				users.users.remove(ind);
			}
		}
	}



}