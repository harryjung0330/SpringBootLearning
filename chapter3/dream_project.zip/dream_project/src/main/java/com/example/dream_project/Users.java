package com.example.dream_project;

import java.util.ArrayList;
import java.util.List;

public class Users
{
    List<User> users = new ArrayList<User>();

    public Users()
    {
        users.addAll(List.of(
                new User("harry", "01011", "a", "123"),
                new User("Dan", "1121", "b", "123")
        ));
    }

}
