package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}



}

@RestController
@RequestMapping("user")
class RestApiController{

	private final UserRepository repository;

	RestApiController(UserRepository userRepository)
	{
		this.repository = userRepository;
	}

	@GetMapping(value ="")
	Iterable<Users> getUsers()
	{
		return repository.findAll();
	}
}

@Repository
interface UserRepository extends CrudRepository<Users, String>
{

}